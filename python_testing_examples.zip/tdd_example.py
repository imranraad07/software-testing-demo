# Step 1: Write failing test first
def test_multiply():
    assert multiply(2, 3) == 6  # This will fail initially

# Step 2: Write minimal implementation
def multiply(a, b):
    return a * b

# Step 3: Refactor if needed (already optimal here)
